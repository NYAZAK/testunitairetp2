using System;
using Xunit;

namespace dark_place_game.tests
{
    
    /// Cette classe contient tout un ensemble de tests unitaires pour la classe CurrencyHolder
    public class CurrencyHolderTest
    {
        public static readonly int EXEMPLE_CAPACITE_VALIDE = 2748;
        public static readonly int EXEMPLE_CONTENANCE_INITIALE_VALIDE = 978;
        public static readonly string EXEMPLE_NOM_MONNAIE_VALIDE = "Brouzouf";

        [Fact]
        public void VraiShouldBeTrue()
        {
            var vrai = true;
            Assert.True(vrai, "Erreur, vrai vaut false. Le test est volontairement mal écrit, corrigez le.");
        }

        [Fact]
        public void CurrencyHolderCreatedWithInitialCurrentAmountOf10ShouldContain10Currency()
        {
            var ch = new CurrencyHolder(EXEMPLE_NOM_MONNAIE_VALIDE,EXEMPLE_CAPACITE_VALIDE , 10);
            var result = ch.CurrentAmount == 10;
            Assert.True(result);
        }

        [Fact]
        public void CurrencyHolderCreatedWithInitialCurrentAmountOf25ShouldContain25Currency()
        {
            var ch = new CurrencyHolder(EXEMPLE_NOM_MONNAIE_VALIDE, EXEMPLE_CAPACITE_VALIDE, 25);
            var result = ch.CurrentAmount == 25;
            Assert.True(result);
        }

        [Fact]
        public void CurrencyHolderCreatedWithInitialCurrentAmountOf0ShouldContain0Currency()
        {
            var ch = new CurrencyHolder(EXEMPLE_NOM_MONNAIE_VALIDE,EXEMPLE_CAPACITE_VALIDE, 0);
            var result = ch.CurrentAmount == 0;
            Assert.True(result);
        }

        [Fact]
        public void CreatingCurrencyHolderWithNegativeContentThrowExeption()
        {
            // Petite subtilité : pour tester les levées d'exeption en c# on est obligé d'utiliser un concept un peu exotique : les expression lambda.
            // sans entrer dans le détail pour déclarer une lambda respectez la syntaxe ci dessous, pour rédiger des tests unitaires elle devrais vous suffire.
            Action mauvaisAppel = () => {new CurrencyHolder(EXEMPLE_NOM_MONNAIE_VALIDE,EXEMPLE_CAPACITE_VALIDE , -10);};
            Assert.Throws<ArgumentException>(mauvaisAppel);
        }


        [Fact]
        public void CreatingCurrencyHolderWithNullNameThrowExeption()
        {
            // Petite subtilité : pour tester les levées d'exeption en c# on est obligé d'utiliser un concept un peu exotique : les expression lambda.
            // sans entrer dans le détail pour déclarer une lambda respectez la syntaxe ci dessous, pour rédiger des tests unitaires elle devrais vous suffire.
            Action mauvaisAppel = () => {new CurrencyHolder(null,EXEMPLE_CAPACITE_VALIDE , EXEMPLE_CONTENANCE_INITIALE_VALIDE);};
            //Assert.NotNull(mauvaisAppel);
            Assert.Throws<ArgumentException>(mauvaisAppel);
        }

        [Fact]
        public void CreatingCurrencyHolderWithEmptyNameThrowExeption()
        {
            // Petite subtilité : pour tester les levées d'exeption en c# on est obligé d'utiliser un concept un peu exotique : les expression lambda.
            // sans entrer dans le détail pour déclarer une lambda respectez la syntaxe ci dessous, pour rédiger des tests unitaires elle devrais vous suffire.
            Action mauvaisAppel = () => {new CurrencyHolder("",EXEMPLE_CAPACITE_VALIDE , EXEMPLE_CONTENANCE_INITIALE_VALIDE);};
            Assert.Throws<ArgumentException>(mauvaisAppel);
        }
        [Fact]
        public void BrouzoufIsAValidCurrencyName ()
        {
            // A vous d'écrire un test qui vérife qu'on peut créer un CurrencyHolder contenant une monnaie dont le nom est Brouzouf
            var ch = new CurrencyHolder(EXEMPLE_NOM_MONNAIE_VALIDE, EXEMPLE_CAPACITE_VALIDE, 25);
            var result = ch.CurrencyName == "Brouzouf";
            Assert.True(result);
        }

    
        [Fact]
        public void DollardIsAValidCurrencyName ()
        {
            // A vous d'écrire un test qui vérife qu'on peut créer un CurrencyHolder contenant une monnaie dont le nom est Dollard
            var ch = new CurrencyHolder("Dollard", EXEMPLE_CAPACITE_VALIDE, 25);
            var result = ch.CurrencyName == "Dollard";
            Assert.True(result);
        }

        [Fact]
        public void TestPut10CurrencyInNonFullCurrencyHolder()
        {
            // A vous d'écrire un test qui vérifie que si on ajoute via la methode put 10 currency à un sac a moité plein,
            // il contient maintenant la bonne quantité de currency
            var ch = new CurrencyHolder(EXEMPLE_NOM_MONNAIE_VALIDE,EXEMPLE_CAPACITE_VALIDE,EXEMPLE_CONTENANCE_INITIALE_VALIDE);
            var store = ch.Store(10);
            var put10 = EXEMPLE_CONTENANCE_INITIALE_VALIDE + 10;
            Assert.True(put10.Equals(store));

        }
/**
        [Fact]
        public void TestPut10CurrencyInNearlyFullCurrencyHolder()
        {
            // A vous d'écrire un test qui vérifie que si on ajoute via la methode put 10 
            // currency à un sac quasiement plein, une exeption NotEnoughtSpaceInCurrencyHolderExeption est levée.
           
            Action sacPlein = () => {new CurrencyHolder(EXEMPLE_NOM_MONNAIE_VALIDE,2748, 2758);  };
            Assert.Throws<ArgumentException>(sacPlein);
        }

**/
        [Fact]
        public void CreatingCurrencyHolderWithNameShorterThan4CharacterThrowExeption()
        {
            // A vous d'écrire un test qui doit échouer s'il es possible de créer un 
            // CurrencyHolder dont Le Nom De monnaie est inférieur a 4 lettres
            var ch = new CurrencyHolder("AZE",EXEMPLE_CAPACITE_VALIDE, 2748);
            var nomCourt = ch.CurrencyName.Length < 4;
            Assert.True(nomCourt, "nom trop cour");
        } 


        [Fact]
        public void WithdrawMoreThanCurrentAmountInCurrencyHolderThrowExeption()
        {
            // A vous d'écrire un test qui vérifie que retirer (methode withdraw) 
            //une quantité negative de currency leve une exeption CantWithDrawNegativeCurrencyAmountExeption.
            // Asruce : dans ce cas prévu avant même de pouvoir compiler le test, 
            //vous allez être obligé de créer 
            //la classe CantWithDrawMoreThanCurrentAmountExeption 
            //(vous pouvez la mettre dans le meme fichier que CurrencyHolder)
            var ch = new CurrencyHolder(EXEMPLE_NOM_MONNAIE_VALIDE,EXEMPLE_CAPACITE_VALIDE , EXEMPLE_CONTENANCE_INITIALE_VALIDE);
            Action mauvaisAppel = () => {ch.Withdraw(10);};
            Assert.Throws<ArgumentException>(mauvaisAppel);
        }
        
 
        [Fact]
        public void CreatingCurrencyHolderWithNameEqualTo12CharacterThrowExeption()
        {
            // A vous d'écrire un test qui doit échouer s'il es possible de créer un 
            // CurrencyHolder dont Le Nom De monnaie est inférieur a 4 lettres
            var ch = new CurrencyHolder("AZE",EXEMPLE_CAPACITE_VALIDE, 2748);
            var currencyName12 = ch.CurrencyName.Length == 12;
            Assert.False(currencyName12, "le nom de la monnaie est egale à 12 caracteres");
        } 

        [Fact]
         public void CreatingCurrencyHolderWithNameInRange4To10CharacterThrowExeption()
        {
            // A vous d'écrire un test qui doit échouer s'il es possible de créer un 
            // CurrencyHolder dont Le Nom De monnaie est inférieur a 4 lettres
            var ch = new CurrencyHolder("AZERTY",EXEMPLE_CAPACITE_VALIDE, 2748);
            var CurrencyName = ch.CurrencyName.Length;
            Assert.InRange(CurrencyName, 4, 10);
        } 

    }
}
