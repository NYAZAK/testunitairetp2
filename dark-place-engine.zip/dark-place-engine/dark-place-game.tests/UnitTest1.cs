using System;
using Xunit;

namespace dark_place_game.tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
