﻿using System;

namespace dark_place_game
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Lancement du jeu Dark Place ...");
            throw new Exception("Le jeu ne semble pas encore codé !");
        }
    }

}

